export interface IMyShiftsProps {
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userDisplayName: string;
  viewMode: 'day' | 'week';
}
