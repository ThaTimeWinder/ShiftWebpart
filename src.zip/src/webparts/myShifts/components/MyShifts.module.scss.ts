
require("./MyShifts.module.css");
const styles = {
  weekCalendarContainer: 'weekCalendarContainer_443d38aa',
  navButton: 'navButton_443d38aa',
  emptyWeekMessage: 'emptyWeekMessage_443d38aa',
  gridContainer: 'gridContainer_443d38aa',
  headerRow: 'headerRow_443d38aa',
  headerCell: 'headerCell_443d38aa',
  bodyRow: 'bodyRow_443d38aa',
  dayColumn: 'dayColumn_443d38aa',
  shiftBlock: 'shiftBlock_443d38aa',
  openShiftBlock: 'openShiftBlock_443d38aa',
  shiftContent: 'shiftContent_443d38aa',
  warningIcon: 'warningIcon_443d38aa',
  hourLinesContainer: 'hourLinesContainer_443d38aa',
  hourLine: 'hourLine_443d38aa',
  hourLabel: 'hourLabel_443d38aa'
};

export default styles;
