
require("./MyShiftsCalendar.module.css");
const styles = {
  container: 'container_c5aab755',
  navButton: 'navButton_c5aab755',
  dateText: 'dateText_c5aab755',
  loadingText: 'loadingText_c5aab755',
  errorText: 'errorText_c5aab755',
  emptyText: 'emptyText_c5aab755',
  realShiftRow: 'realShiftRow_c5aab755',
  openShiftRow: 'openShiftRow_c5aab755',
  timeText: 'timeText_c5aab755',
  openTimeText: 'openTimeText_c5aab755',
  details: 'details_c5aab755',
  openIcon: 'openIcon_c5aab755',
  openText: 'openText_c5aab755',
  emptyWeekMessage: 'emptyWeekMessage_c5aab755',
  weekContainer: 'weekContainer_c5aab755',
  headerRow: 'headerRow_c5aab755',
  hourHeader: 'hourHeader_c5aab755',
  dayHeader: 'dayHeader_c5aab755',
  hourGrid: 'hourGrid_c5aab755',
  hourRow: 'hourRow_c5aab755',
  hourLabel: 'hourLabel_c5aab755',
  dayColumn: 'dayColumn_c5aab755',
  shiftBlock: 'shiftBlock_c5aab755',
  shiftInfo: 'shiftInfo_c5aab755',
  shiftTime: 'shiftTime_c5aab755',
  shiftTeam: 'shiftTeam_c5aab755',
  overlapIcon: 'overlapIcon_c5aab755',
  status: 'status_c5aab755',
  error: 'error_c5aab755'
};

export default styles;
