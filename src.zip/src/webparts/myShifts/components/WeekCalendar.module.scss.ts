
require("./WeekCalendar.module.css");
const styles = {
  weekContainer: 'weekContainer_1836a029',
  headerRow: 'headerRow_1836a029',
  hourHeader: 'hourHeader_1836a029',
  dayHeader: 'dayHeader_1836a029',
  hourGrid: 'hourGrid_1836a029',
  hourRow: 'hourRow_1836a029',
  hourLabel: 'hourLabel_1836a029',
  dayColumn: 'dayColumn_1836a029',
  shiftBlock: 'shiftBlock_1836a029',
  overlapIcon: 'overlapIcon_1836a029',
  shiftInfo: 'shiftInfo_1836a029',
  shiftTime: 'shiftTime_1836a029',
  shiftTeam: 'shiftTeam_1836a029',
  status: 'status_1836a029',
  error: 'error_1836a029'
};

export default styles;
