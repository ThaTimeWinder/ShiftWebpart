// src/webparts/myShifts/components/WeekCalendar.tsx
import * as React from 'react';
import { useState } from 'react';
import { DateTime } from 'luxon';
import { MSGraphClientV3 } from '@microsoft/sp-http';
import { Icon, DefaultButton, Text } from '@fluentui/react';

import { getShiftsForDay, IShift } from '../services/ShiftsService';
import styles from './WeekCalendar.module.scss';

export interface IWeekCalendarProps {
  graphClient: MSGraphClientV3;
  userId: string;
  tz: string;
}

const HOURS_PER_DAY = 24;
const MINUTES_PER_DAY = 24 * 60;

/**
 * Hjælperfunktion: opretter en array [0,1,2,…,len-1]
 */
function range(len: number): number[] {
  return Array.from({ length: len }, (_, i) => i);
}

/**
 * computeOverlapCols: returnerer en “kolonne‐index” for hver shift i shiftsForDay.
 * Hvis to vagter overlapper i tid, får de forskellige kolonne‐indeks.
 */
function computeOverlapCols(shiftsForDay: IShift[]): number[] {
  const len = shiftsForDay.length;
  const cols: number[] = new Array(len).fill(0);

  for (let i = 0; i < len; i++) {
    const s1 = DateTime.fromISO(shiftsForDay[i].sharedShift.startDateTime);
    const e1 = DateTime.fromISO(shiftsForDay[i].sharedShift.endDateTime);
    let col = 0;

    for (let j = 0; j < i; j++) {
      const s2 = DateTime.fromISO(shiftsForDay[j].sharedShift.startDateTime);
      const e2 = DateTime.fromISO(shiftsForDay[j].sharedShift.endDateTime);
      const overlaps = s1 < e2 && s2 < e1;
      if (overlaps && cols[j] === col) {
        col++;
        j = -1; // start forfra, så vi ikke får collision
      }
    }

    cols[i] = col;
  }

  return cols;
}

const WeekCalendar: React.FC<IWeekCalendarProps> = ({ graphClient, userId, tz }) => {
  // 1) Beregn “nuværende” ugeStart som onsdag i indeværende uge:
  const today = DateTime.now().setZone(tz);
  const initialWeekStart = today.startOf('week').plus({ days: 2 }); // Monday + 2 = Wednesday

  // 2) Gem ugeStart som state, så vi kan ændre den med navigation
  const [weekStart, setWeekStart] = useState<DateTime>(initialWeekStart);

  // 3) Re‐beregn “dages‐array” hver gang weekStart ændrer sig
  const [days, setDays] = useState<DateTime[]>(
    range(7).map((i) => initialWeekStart.plus({ days: i }))
  );

  // 4) Tilstand til at gemme shifts pr. dag
  const [daysShifts, setDaysShifts] = useState<{ date: DateTime; shifts: IShift[] }[]>([]);

  // 5) Loading + error flags
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // 6) Når weekStart ændrer sig, opdater “days” og hent nye vagter:
  React.useEffect(() => {
    // Byg nyt “days” array
    const newDays = range(7).map((i) => weekStart.plus({ days: i }));
    setDays(newDays);

    let cancelled = false;
    async function loadWeek() {
      setLoading(true);
      setError(null);

      try {
        const promises = newDays.map(async (d) => {
          const result = await getShiftsForDay(graphClient, d, userId);
          return { date: d, shifts: result };
        });
        const results = await Promise.all(promises);
        if (!cancelled) {
          setDaysShifts(results);
        }
      } catch (e) {
        if (!cancelled) {
          const msg = e instanceof Error ? e.message : String(e);
          setError(msg);
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    loadWeek();
    return () => {
      cancelled = true;
    };
  }, [weekStart, graphClient, userId, tz]);

  // 7) Navigations‐funktioner:
  const goPreviousWeek = (): void => {
    setWeekStart((prev) => prev.minus({ days: 7 }));
  };
  const goNextWeek = (): void => {
    setWeekStart((prev) => prev.plus({ days: 7 }));
  };

  // 8) Render loading / error / empty‐week beskeder:
  if (loading) {
    return <div className={styles.status}>Indlæser vagter…</div>;
  }
  if (error) {
    return <div className={styles.error}>Fejl under indlæsning: {error}</div>;
  }
  const allEmpty = daysShifts.every((ds) => ds.shifts.length === 0);
  if (allEmpty) {
    return <div className={styles.status}>Ingen vagter i denne uge 🎉</div>;
  }

  // 9) Selve ugekalender‐grid’et:
  return (
    <div className={styles.weekContainer}>
      {/* --- Navigation + overskrift for ugedatoer --- */}
      <div className={styles.toolbar}>
        <DefaultButton
          className={styles.navButton}
          onClick={goPreviousWeek}
          text="← Forrige uge"
        />
        <Text variant="large" className={styles.weekLabel}>
          {`Uge ${weekStart.weekNumber} (${weekStart.toFormat('dd/LL')} – ${weekStart
            .plus({ days: 6 })
            .toFormat('dd/LL')})`}
        </Text>
        <DefaultButton
          className={styles.navButton}
          onClick={goNextWeek}
          text="Næste uge →"
        />
      </div>

      {/* --- Header‐række: tom hjørne + hver dags navn/dato --- */}
      <div className={styles.headerRow}>
        <div className={styles.hourHeader} />
        {days.map((dayDt) => (
          <div key={dayDt.toISODate()} className={styles.dayHeader}>
            {dayDt.toFormat('ccc, dd LLL yyyy')}
          </div>
        ))}
      </div>

      {/* --- Time‐grid: 24 rækker á 60px høj + 7 kolonner --- */}
      <div className={styles.hourGrid}>
        {range(HOURS_PER_DAY).map((hour) => (
          <div key={hour} className={styles.hourRow}>
            <div className={styles.hourLabel}>
              {DateTime.fromObject({ hour }).toFormat('HH:mm')}
            </div>
            {range(7).map((dayIdx) => (
              <div key={dayIdx} className={styles.dayColumn} />
            ))}
          </div>
        ))}

        {/* --- Placér alle vagt‐blokkene ovenpå grid’et --- */}
        {daysShifts.map((ds, dayIndex) => {
          // Beregn overlap‐kolonner for dagen:
          const cols = computeOverlapCols(ds.shifts);
          const maxCols = cols.length > 0 ? Math.max(...cols) + 1 : 1;

          return ds.shifts.map((shift, idx) => {
            const start = DateTime.fromISO(
              shift.sharedShift.startDateTime
            ).setZone(tz);
            const end = DateTime.fromISO(
              shift.sharedShift.endDateTime
            ).setZone(tz);

            const startMinutes = start.hour * 60 + start.minute;
            const topPct = (startMinutes / MINUTES_PER_DAY) * 100;
            const shiftMinutes =
              (end.hour * 60 + end.minute) -
              (start.hour * 60 + start.minute);
            const heightPct = (shiftMinutes / MINUTES_PER_DAY) * 100;

            const colIdx = cols[idx];
            const widthPct = 100 / maxCols;

            // Beregn “left” og “width” inden for hele grid’et:
            // Hver dagkolonne = 1/7 af containerens bredde.
            const leftPct =
              (dayIndex * 100) / 7 + (colIdx * widthPct) / 7;
            const blockWidthPct = (widthPct / 7) * 100;

            const style: React.CSSProperties = {
              top: `${topPct}%`,
              height: `${heightPct}%`,
              left: `${leftPct}%`,
              width: `${blockWidthPct}%`,
              backgroundColor: '#0078d4',
              color: '#ffffff'
            };

            return (
              <div
                key={shift.id}
                className={styles.shiftBlock}
                style={style}
              >
                <div className={styles.shiftInfo}>
                  <span className={styles.shiftTime}>
                    {`${start.toFormat('HH:mm')} – ${end.toFormat('HH:mm')}`}
                  </span>
                  <span className={styles.shiftTeam}>
                    {shift.teamInfo?.displayName ?? shift.teamId}
                  </span>
                </div>
                {cols.filter((c) => c === colIdx).length > 1 && (
                  <Icon
                    iconName="WarningSolid"
                    className={styles.overlapIcon}
                  />
                )}
              </div>
            );
          });
        })}
      </div>
    </div>
  );
};

export default WeekCalendar;
